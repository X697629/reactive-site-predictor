# 🧠 Reactive Site Predictor — Usage Guide

> Predicts reactive residues from a given PDB file. Supports metal-aware ZORA boost, pocket detection, 6+20D environment vector, and deterministic output.

---

## 📦 1. Installation (Anaconda recommended)

```bash
conda create -y --prefix D:/conda_envs/bioenv python=3.8
conda activate D:/conda_envs/bioenv
conda install -y -c conda-forge numpy biopython
# Optional: install mdtraj for pocket detection
conda install -y -c conda-forge mdtraj
```

---

## 🚀 2. Example Execution

```bash
# Basic prediction (top 10 residues)
python reactive_site_predictor.py 4rub.pdb --top 10

# Enable pocket detection (optional, requires mdtraj)
set POCKET_ON=1                   # CMD (PowerShell: $Env:POCKET_ON = "1")
python reactive_site_predictor.py 4rub.pdb --top 10

# Use embedding weights (20-dim JSON list)
python reactive_site_predictor.py 4rub.pdb --top 10 --embed-weights "[0.1,0.0,0.2,...]"
```

---

## 📁 3. Input File Requirements

- Standard PDB format with at least CA atoms present.
- Metal ions (ZN, MG, CU, FE, CA, etc.) are automatically detected and ZORA boost is applied.

---

## 📤 4. Output Example

```plaintext
A:GLU 204     19.03
A:ASP 203     18.55
...
```

- Format: chain:resname number — predicted reactivity score
- Higher scores indicate more reactive candidates.

---

## 🧪 5. Validated Protein Examples

- `4rub.pdb` (Rubisco)
- `1ca2.pdb1.gz` (mitochondrial complex)
- `2c7c.pdb` (test structure)

---

## 🔁 6. Determinism

- Random seed fixed: `random.seed(0)`, `np.random.seed(0)`, `PYTHONHASHSEED=0`
- Repeated runs produce identical outputs, even after restarting Anaconda or rebooting.

---

## ❗ Troubleshooting

- `ModuleNotFoundError`: ensure required packages (`biopython`, `mdtraj`) are installed
- `can't open file`: check your working directory and file paths
- `POCKET_ON` ineffective: CMD vs PowerShell use different syntax for environment variables

---

## ✅ Maintenance Tips

- For performance: optimize neighbor search with `KDTree`, `Numba`, or `Cython`
- To add new metals: update `ZORA_PARAMS` with new alpha/beta values
- To extend residue types: update `AA_LIST` and `AA_TO_VEC` accordingly

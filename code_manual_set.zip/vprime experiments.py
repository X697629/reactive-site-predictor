#!/usr/bin/env python3
"""vprime_experiments.py — Run Experiments A, B, C′ on arbitrary V′ samples
================================================================================
CLI usage (examples)
--------------------
# 20 random V′ samples using default geometry
python vprime_experiments.py --samples 20 --output summary.csv

# One fixed coordinate file previously saved (reproduce identical run)
python vprime_experiments.py --coords coords_fixed.npy --seed 0

Description
-----------
* A sample V′ is a discrete manifold that passes Definition 3.1 of the paper
  (≥3 Å minimum spacing, local‑chart radius ≤3.5 Å, etc.).
* Experiment A: K‑means clustering (k=3) on 10‑dim environment vectors → ARI.
* Experiment B: mean intra‑ vs inter‑class distances among the first 5 reactive
  residues.
* Experiment C′: Random‑Forest baseline precision / recall on the same labels.

Outputs
-------
* Prints mean ± std across all samples to stdout.
* If --output is given, also writes a CSV summary (one row per sample).
"""
import argparse, sys, pathlib, json
import numpy as np
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.metrics import adjusted_rand_score, pairwise_distances, precision_score, recall_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KDTree
import pandas as pd
EFF_Q  = 0.65
TYPE_W = 0.25         

def choose_best_k(Ep, rng, k_min=2, k_max=5):
    """Return (best_k, labels) that maximise silhouette score."""
    best_k, best_lbl, best_score = k_min, None, -1
    for k in range(k_min, k_max + 1):
        lbl = KMeans(k, n_init=10,
                     random_state=rng.integers(0,10_000)).fit_predict(Ep)
        score = silhouette_score(Ep, lbl)
        if score > best_score:
            best_k, best_lbl, best_score = k, lbl, score
    return best_k, best_lbl

def generate_coordinates(n: int, box: float, rng: np.random.Generator) -> np.ndarray:
    """Uniform random 3‑D coordinates obeying ≥3 Å minimum spacing."""
    coords = []
    while len(coords) < n:
        cand = rng.uniform(0, box, size=3)
        if all(np.linalg.norm(cand - c) > 3.0 for c in coords):
            coords.append(cand)
    return np.vstack(coords)


def neighbor_list(coords: np.ndarray, radius: float) -> list[np.ndarray]:
    return KDTree(coords).query_radius(coords, r=radius)


def environment_vectors(coords: np.ndarray, idxs: list[np.ndarray], rng: np.random.Generator) -> np.ndarray:
    """Compute the 10‑dim Ep vector (paper Appendix A)."""
    n = len(coords)
    Ep = np.zeros((n, 10))
    for i, nb in enumerate(idxs):
        nb = nb[nb != i]
        if len(nb) == 0:
            Ep[i] = rng.normal(0, 0.1, 10)
            continue
        charges = rng.normal(0, 1, len(nb))
        vecs = coords[nb] - coords[i]
        dist = np.linalg.norm(vecs, axis=1, keepdims=True) + 1e-6
        dirs = vecs / dist
        Ep[i,0] = charges.mean()                     # E1
        Ep[i,1] = np.linalg.norm((charges[:,None] * dirs).sum(axis=0))   # E2
        Ep[i, 2] = dirs.var(axis=0).mean() * len(nb)
        Ep[i, 3] = 1.0                                 # µE term (constant)
        Ep[i, 4] = 1.0 / len(nb)                       # SASA proxy
        Ep[i,5] = TYPE_W * rng.integers(0, 10)        # residue type ID
        Ep[i, 6] = np.linalg.norm(dirs.mean(axis=0))   # density proxy
        Ep[i, 7] = len(nb)
        Ep[i, 8] = dist.mean()
        Ep[i, 9] = dist.max()

    # ----- 전하 가중치 :  w_q = 0.65 / |q|min -----
    q_abs_max = max(1e-6, np.max(np.abs(Ep[:,0])))
    w_q       = EFF_Q / q_abs_max
    Ep[:,0] *= w_q
    Ep[:,1] *= w_q

    # z-score normalisation
    Ep = (Ep - Ep.mean(axis=0)) / Ep.std(axis=0)
    return Ep

# ----------------------------------------------------------------------------
# Experiment routines
# ----------------------------------------------------------------------------

def experiment_A(Ep: np.ndarray, rng: np.random.Generator) -> float:
    labels_true = np.zeros(len(Ep), dtype=int); labels_true[:5] = 1
    k_opt, pred = choose_best_k(Ep, rng, k_min=2, k_max=3)
    #if s == 0:
     #   print(f"[auto-k] selected k = {k_opt}")
    return adjusted_rand_score(labels_true, pred)


def experiment_B(Ep: np.ndarray) -> tuple[float, float]:
    labels_true = np.zeros(len(Ep), dtype=int); labels_true[:5] = 1
    D = pairwise_distances(Ep)
    reactive = np.where(labels_true == 1)[0]
    nonreact = np.where(labels_true == 0)[0]
    intra = D[np.ix_(reactive, reactive)].mean()
    inter = D[np.ix_(reactive, nonreact)].mean()
    return intra, inter


def experiment_Cprime(Ep: np.ndarray, rng: np.random.Generator) -> tuple[float, float]:
    # same true labels as A/B for consistency
    labels_true = np.zeros(len(Ep), dtype=int); labels_true[:5] = 1
    clf = RandomForestClassifier(random_state=rng.integers(0, 10_000)).fit(Ep, labels_true)
    pred = clf.predict(Ep)
    return precision_score(labels_true, pred), recall_score(labels_true, pred)

# ----------------------------------------------------------------------------
# Main runner
# ----------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser(description="Run Experiments A, B, C′ on V′ samples")
    p.add_argument("--samples", type=int, default=20, help="# of random V′ samples (default 20)")
    p.add_argument("--residues", type=int, default=60, help="residue count n (default 60)")
    p.add_argument("--box", type=float, default=20.0, help="box size Å (default 20.0)")
    p.add_argument("--radius", type=float, default=3.5, help="neighbor radius Å (default 3.5)")
    p.add_argument("--seed", type=int, default=0, help="global RNG seed (default 0)")
    p.add_argument("--coords", type=pathlib.Path, help=".npy file with fixed coordinates (skip random)" )
    p.add_argument("--output", type=pathlib.Path, help="CSV file to save per‑sample metrics")
    args = p.parse_args()

    rng_global = np.random.default_rng(args.seed)

    rows = []
    for s in range(args.samples):
        rng = np.random.default_rng(rng_global.integers(0, 2**32-1))

        # --- geometry ---
        if args.coords:
            coords = np.load(args.coords)
        else:
            coords = generate_coordinates(args.residues, args.box, rng)
        idxs   = neighbor_list(coords, args.radius)
        Ep     = environment_vectors(coords, idxs, rng)

        # --- experiments ---
        ari           = experiment_A(Ep, rng)
        intra, inter  = experiment_B(Ep)
        prec, rec     = experiment_Cprime(Ep, rng)

        rows.append(dict(sample=s, ARI=ari, intra=intra, inter=inter, prec=prec, rec=rec))

    df = pd.DataFrame(rows)
    print("=== V′ experiments summary ({} samples) ===".format(args.samples))
    for col in ["ARI", "intra", "inter", "prec", "rec"]:
        print(f"{col:6}: {df[col].mean():.3f} ± {df[col].std():.3f}")

    if args.output:
        df.to_csv(args.output, index=False)
        print(f"\nPer-sample metrics written to {args.output}")

if __name__ == "__main__":
    main()
